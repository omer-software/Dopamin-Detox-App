package com.daltech.bosluk.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daltech.bosluk.ui.theme.*

@Composable
fun Eyebrow(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), modifier = modifier, color = Moss,
        fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 2.sp)
}

@Composable
fun SelectChip(label: String, icon: String, selected: Boolean, warm: Boolean = false, onClick: () -> Unit) {
    val activeBg = if (warm) Danger else Moss
    Row(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (selected) activeBg else Color.Transparent)
            .border(BorderStroke(1.dp, if (selected) activeBg else LineColor), RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Text(icon, fontSize = 15.sp)
        Text(label, color = if (selected) Paper else Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Paper, disabledContainerColor = LineColor)
    ) { Text(text, fontSize = 16.sp) }
}

@Composable
fun StepBar(step: Int, total: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        repeat(total) { i ->
            Box(
                Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp))
                    .background(if (i < step) Moss else LineColor)
            )
        }
    }
}
