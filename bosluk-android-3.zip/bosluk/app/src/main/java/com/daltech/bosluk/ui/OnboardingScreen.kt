package com.daltech.bosluk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daltech.bosluk.OnboardingState
import com.daltech.bosluk.data.Content
import com.daltech.bosluk.ui.theme.*
import com.daltech.bosluk.usage.AppUsageInfo

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    ob: OnboardingState,
    onSetName: (String) -> Unit,
    onGoScreenTime: () -> Unit,
    onRecheckUsage: () -> Unit,
    onOpenUsageSettings: () -> Unit,
    onToggleExcuse: (String) -> Unit,
    onGoHobby: () -> Unit,
    onToggleHobby: (String) -> Unit,
    onGoTrigger: () -> Unit,
    onToggleTrigger: (String) -> Unit,
    onGoPlan: () -> Unit,
    onGoUsername: () -> Unit,
    onSetUsername: (String) -> Unit,
    onFinish: () -> Unit,
    onBack: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().background(Paper).verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 26.dp)
    ) {
        StepBar(ob.step, 6)
        Spacer(Modifier.height(18.dp))

        when (ob.step) {
            1 -> StepName(ob.name, onSetName, onGoScreenTime)
            2 -> StepScreenTime(ob, onRecheckUsage, onOpenUsageSettings, onToggleExcuse, onGoHobby, onBack)
            3 -> StepHobby(ob, onToggleHobby, onGoTrigger, onBack)
            4 -> StepTrigger(ob, onToggleTrigger, onGoPlan, onBack)
            5 -> StepPlan(ob, onGoUsername)
            6 -> StepUsername(ob, onSetUsername, onFinish, onBack)
        }
    }
}

@Composable
private fun StepName(name: String, onSetName: (String) -> Unit, onNext: () -> Unit) {
    Eyebrow("Kurulum · 1/6")
    Spacer(Modifier.height(14.dp))
    Text("Sana nasıl\nseslenelim?", style = MaterialTheme.typography.displaySmall, color = Ink)
    Spacer(Modifier.height(12.dp))
    Text("Ad soyadınla başlayalım. Bu sadece senin defterin.", color = Fade, fontSize = 15.sp)
    Spacer(Modifier.height(22.dp))
    OutlinedTextField(
        value = name, onValueChange = onSetName,
        placeholder = { Text("Ad Soyad") },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Moss, unfocusedBorderColor = LineColor,
            focusedTextColor = Ink, unfocusedTextColor = Ink
        )
    )
    Spacer(Modifier.height(28.dp))
    PrimaryButton("Devam", enabled = name.isNotBlank(), onClick = onNext)
}

@Composable
private fun StepScreenTime(
    ob: OnboardingState,
    onRecheck: () -> Unit,
    onOpenSettings: () -> Unit,
    onToggleExcuse: (String) -> Unit,
    onNext: () -> Unit,
    onBack: () -> Unit,
) {
    Eyebrow("Kurulum · 2/6")
    Spacer(Modifier.height(14.dp))
    Text("Şu anki\ndurumun", style = MaterialTheme.typography.displaySmall, color = Ink)
    Spacer(Modifier.height(12.dp))
    Text("Gerçek verinle başlıyoruz. Yargılamıyoruz — sadece görüyoruz.", color = Fade, fontSize = 15.sp)
    Spacer(Modifier.height(22.dp))

    when {
        ob.loadingUsage -> Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Moss)
        }
        !ob.usageAccessGranted -> {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PaperCard)
                    .padding(18.dp)
            ) {
                Text("Kullanım erişimi gerekiyor", fontFamily = FontFamily.Serif, fontSize = 17.sp, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Ekran sürenizi ve en çok kullandığınız uygulamaları görebilmemiz için Ayarlar'dan izin vermen lazım.",
                    color = Fade, fontSize = 13.5.sp
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onOpenSettings, shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Brass, contentColor = androidx.compose.ui.graphics.Color.White)
                ) { Text("Ayarları aç") }
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onRecheck, modifier = Modifier.fillMaxWidth()) { Text("İzni verdim, tekrar dene", color = Moss) }
        }
        else -> {
            Text(
                "${ob.screenTimeMin} dk", style = MaterialTheme.typography.displaySmall, color = MossDeep
            )
            Text("BUGÜNKÜ TOPLAM EKRAN SÜREN".uppercase(), color = Fade, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(20.dp))
            Text("EN ÇOK KULLANDIKLARIN", color = Moss, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(10.dp))
            ob.topApps.forEach { app -> AppUsageRow(app, ob.excuses[app.packageName] ?: false) { onToggleExcuse(app.packageName) } }
            if (ob.topApps.isEmpty()) Text("Bugün için yeterli veri yok.", color = Fade, fontSize = 13.sp)
        }
    }

    Spacer(Modifier.height(28.dp))
    if (ob.usageAccessGranted) PrimaryButton("Devam", onClick = onNext)
    TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("← Geri", color = Fade) }
}

@Composable
private fun AppUsageRow(app: AppUsageInfo, isWork: Boolean, onToggle: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(app.label, color = Ink, fontSize = 14.5.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("${app.minutes} dk", color = Fade, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        }
        Spacer(Modifier.height(6.dp))
        SelectChip("İş için kullanıyorum", "💼", isWork, onClick = onToggle)
        HorizontalDivider(color = LineColor, modifier = Modifier.padding(top = 10.dp))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StepHobby(ob: OnboardingState, onToggle: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    Eyebrow("Kurulum · 3/6")
    Spacer(Modifier.height(14.dp))
    Text("Neyi\nseversin?", style = MaterialTheme.typography.displaySmall, color = Ink)
    Spacer(Modifier.height(12.dp))
    Text("Quest'lerin buradan doğacak. Boşa kalan dikkatini bu yönlere çekeceğiz.", color = Fade, fontSize = 15.sp)
    Spacer(Modifier.height(22.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Content.hobbies.forEach { h -> SelectChip(h.label, h.icon, h.id in ob.hobbies) { onToggle(h.id) } }
    }
    Spacer(Modifier.height(28.dp))
    PrimaryButton("Devam · ${ob.hobbies.size} seçili", enabled = ob.hobbies.isNotEmpty(), onClick = onNext)
    TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("← Geri", color = Fade) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StepTrigger(ob: OnboardingState, onToggle: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    Eyebrow("Kurulum · 4/6")
    Spacer(Modifier.height(14.dp))
    Text("Nerede\nkaybediyorsun?", style = MaterialTheme.typography.displaySmall, color = Ink)
    Spacer(Modifier.height(12.dp))
    Text("Dikkatinin en çok sızdığı anlar. Tam o anlarda doğru quest'i önümüze koyacağız.", color = Fade, fontSize = 15.sp)
    Spacer(Modifier.height(22.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Content.triggers.forEach { t -> SelectChip(t.label, t.icon, t.id in ob.triggers, warm = true) { onToggle(t.id) } }
    }
    Spacer(Modifier.height(28.dp))
    PrimaryButton("Planımı hazırla", enabled = ob.triggers.isNotEmpty(), onClick = onNext)
    TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("← Geri", color = Fade) }
}

@Composable
private fun StepPlan(ob: OnboardingState, onNext: () -> Unit) {
    Eyebrow("Kurulum · 5/6")
    Spacer(Modifier.height(14.dp))
    Text("Senin\nplanın", style = MaterialTheme.typography.displaySmall, color = Ink)
    Spacer(Modifier.height(18.dp))

    if (ob.planLoading || ob.plan == null) {
        Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Moss)
            Spacer(Modifier.height(14.dp))
            Text("Verilerin analiz ediliyor…", color = Fade, fontSize = 13.5.sp)
        }
    } else {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PaperCard).padding(18.dp)
        ) {
            Text("· SANA GÖRE HAZIRLANDI", color = Moss, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(10.dp))
            Text(ob.plan.planText, color = Ink, fontSize = 15.sp, lineHeight = 22.sp)
            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = LineColor)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${ob.plan.dailyGoalMinutes} dk", fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, color = MossDeep)
                Spacer(Modifier.width(8.dp))
                Text("günlük hedef".uppercase(), color = Fade, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(28.dp))
        PrimaryButton("Devam", onClick = onNext)
    }
}

@Composable
private fun StepUsername(ob: OnboardingState, onSetUsername: (String) -> Unit, onFinish: () -> Unit, onBack: () -> Unit) {
    Eyebrow("Kurulum · 6/6")
    Spacer(Modifier.height(14.dp))
    Text("Son bir şey —\nkullanıcı adın", style = MaterialTheme.typography.displaySmall, color = Ink)
    Spacer(Modifier.height(12.dp))
    Text("Ana ekranda seni böyle çağıracağız. Kısa bir takma ad da olur.", color = Fade, fontSize = 15.sp)
    Spacer(Modifier.height(22.dp))
    OutlinedTextField(
        value = ob.username, onValueChange = onSetUsername,
        placeholder = { Text(ob.name.ifBlank { "Kullanıcı adı" }) },
        modifier = Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Moss, unfocusedBorderColor = LineColor)
    )
    Spacer(Modifier.height(28.dp))
    PrimaryButton("Defteri aç", onClick = onFinish)
    TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("← Geri", color = Fade) }
}
