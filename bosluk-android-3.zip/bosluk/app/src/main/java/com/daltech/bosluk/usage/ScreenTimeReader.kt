package com.daltech.bosluk.usage

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import com.daltech.bosluk.data.Content
import java.util.Calendar
import java.util.concurrent.TimeUnit

data class AppUsageInfo(val packageName: String, val label: String, val minutes: Int)

object ScreenTimeReader {

    private fun startOfToday(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun startOfDate(dateEpochDayMillis: Long): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.timeInMillis = dateEpochDayMillis
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        return start to (start + TimeUnit.DAYS.toMillis(1))
    }

    private fun isIgnored(pkg: String) = Content.ignoredPrefixes.any { pkg.startsWith(it) }

    /** Bugün, gece yarısından şu ana kadar toplam ekran süresi (dk). */
    fun todayTotalMinutes(ctx: Context): Int {
        if (!UsageTracker.hasUsageAccess(ctx)) return 0
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = usm.queryAndAggregateUsageStats(startOfToday(), System.currentTimeMillis())
        val totalMs = stats.values
            .filterNot { isIgnored(it.packageName) }
            .sumOf { it.totalTimeInForeground }
        return (totalMs / 60000L).toInt()
    }

    /** Belirli bir tarihin (epoch millis, o günün herhangi bir saati) toplam ekran süresi (dk). */
    fun totalMinutesForDate(ctx: Context, epochMillisInDay: Long): Int {
        if (!UsageTracker.hasUsageAccess(ctx)) return 0
        val (start, end) = startOfDate(epochMillisInDay)
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = usm.queryAndAggregateUsageStats(start, end)
        val totalMs = stats.values
            .filterNot { isIgnored(it.packageName) }
            .sumOf { it.totalTimeInForeground }
        return (totalMs / 60000L).toInt()
    }

    /** Bugün en çok kullanılan [limit] uygulama, süreye göre azalan. */
    fun topAppsToday(ctx: Context, limit: Int = 6): List<AppUsageInfo> {
        if (!UsageTracker.hasUsageAccess(ctx)) return emptyList()
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = usm.queryAndAggregateUsageStats(startOfToday(), System.currentTimeMillis())
        val pm = ctx.packageManager
        return stats.values
            .filterNot { isIgnored(it.packageName) }
            .filter { it.totalTimeInForeground > 0 }
            .sortedByDescending { it.totalTimeInForeground }
            .take(limit)
            .map { u ->
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(u.packageName, 0)).toString()
                } catch (e: PackageManager.NameNotFoundException) {
                    u.packageName
                }
                AppUsageInfo(u.packageName, label, (u.totalTimeInForeground / 60000L).toInt())
            }
    }
}
