package com.daltech.bosluk.ai

import com.daltech.bosluk.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini Developer API'ye doğrudan REST çağrısı (Firebase gerekmez).
 * Key: BuildConfig.GEMINI_API_KEY (local.properties veya ortam değişkeninden gelir).
 * Ücretsiz key: https://aistudio.google.com/apikey
 */
object GeminiClient {

    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    val hasKey: Boolean get() = BuildConfig.GEMINI_API_KEY.isNotBlank()

    /** Basit metin promptu gönderir, model çıktısını (düz metin) döndürür. Hata olursa null. */
    suspend fun generate(prompt: String): String? = withContext(Dispatchers.IO) {
        if (!hasKey) return@withContext null
        try {
            val url = URL(ENDPOINT)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
            conn.doOutput = true
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000

            val body = JSONObject().put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts", JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            if (conn.responseCode !in 200..299) {
                conn.errorStream?.close()
                return@withContext null
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val json = JSONObject(text)
            val candidates = json.optJSONArray("candidates") ?: return@withContext null
            if (candidates.length() == 0) return@withContext null
            val parts = candidates.getJSONObject(0)
                .getJSONObject("content")
                .optJSONArray("parts") ?: return@withContext null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            val result = sb.toString().trim()
            if (result.isBlank()) null else result
        } catch (e: Exception) {
            null
        }
    }
}
