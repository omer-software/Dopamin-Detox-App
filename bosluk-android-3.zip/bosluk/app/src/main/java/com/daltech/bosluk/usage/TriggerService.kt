package com.daltech.bosluk.usage

import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import com.daltech.bosluk.ai.GeminiRepository
import com.daltech.bosluk.data.BoslukRepository
import com.daltech.bosluk.data.Content
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Foreground servis. Her POLL_MS'de bir iki şeyi kontrol eder:
 *  1) İzlenen (hassas nokta) uygulamalar son pencerede eşik kadar açıldıysa -> mikro-quest bildirimi
 *  2) Günlük ekran süresi hedefi aşıldıysa VE yeni bir uygulama ön plana geldiyse -> overlay müdahalesi
 */
class TriggerService : Service() {

    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private lateinit var repo: BoslukRepository

    private val notifiedRecently = HashMap<String, Long>()   // pkg -> cooldown bitiş (ms)
    private val overlayedRecently = HashMap<String, Long>()

    override fun onCreate() {
        super.onCreate()
        repo = BoslukRepository(applicationContext)
        QuestNotifier.ensureChannels(this)
        startForeground(SERVICE_ID, QuestNotifier.serviceNotification(this))
        scope.launch {
            while (true) {
                runCatching { tick() }
                delay(POLL_MS)
            }
        }
    }

    private suspend fun tick() {
        if (!UsageTracker.hasUsageAccess(this)) return

        checkMicroQuestTriggers()
        checkGoalOverlay()
    }

    /** Mekanizma 1: hassas nokta app'i N kez açıldıysa mikro-quest bildirimi. */
    private fun checkMicroQuestTriggers() {
        val now = System.currentTimeMillis()
        val counts = UsageTracker.foregroundOpenCounts(this, Content.watchedPackages, WINDOW_MS)
        counts.forEach { (pkg, n) ->
            val cooldownUntil = notifiedRecently[pkg] ?: 0L
            if (n >= THRESHOLD && now > cooldownUntil) {
                val quest = Content.microQuestForPackage(pkg) ?: return@forEach
                QuestNotifier.fireMicroQuest(this, appLabel(pkg), quest)
                notifiedRecently[pkg] = now + COOLDOWN_MS
            }
        }
    }

    /** Mekanizma 2: günlük hedef aşıldıysa ve yeni bir app açıldıysa overlay göster. */
    private suspend fun checkGoalOverlay() {
        if (!OverlayController.canDrawOverlays(this)) return
        if (OverlayController.isShowing()) return

        val profile = repo.getProfile()
        if (!profile.onboarded || profile.dailyGoalMinutes <= 0) return

        val minutes = ScreenTimeReader.todayTotalMinutes(this)
        val over = minutes - profile.dailyGoalMinutes
        if (over <= 0) return

        val last = UsageTracker.lastForegroundEvent(this, POLL_MS * 2) ?: return
        val (pkg, _) = last
        if (pkg == packageName) return

        val now = System.currentTimeMillis()
        val cooldownUntil = overlayedRecently[pkg] ?: 0L
        if (now <= cooldownUntil) return

        val label = appLabel(pkg)
        val message = GeminiRepository.motivationalMessage(label, over)

        OverlayController.show(
            ctx = this,
            appLabel = label,
            message = message,
            onContinueAnyway = { overlayedRecently[pkg] = now + OVERLAY_COOLDOWN_MS },
            onOpenBosluk = {
                overlayedRecently[pkg] = now + OVERLAY_COOLDOWN_MS
                val open = Intent(this, com.daltech.bosluk.MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(open)
            }
        )
        overlayedRecently[pkg] = now + OVERLAY_COOLDOWN_MS
    }

    private fun appLabel(pkg: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        "Bu uygulama"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { scope.coroutineContext[Job]?.cancel(); OverlayController.dismiss(); super.onDestroy() }

    companion object {
        private const val SERVICE_ID = 42
        private const val POLL_MS = 45_000L
        private const val WINDOW_MS = 15 * 60_000L
        private const val COOLDOWN_MS = 30 * 60_000L
        private const val THRESHOLD = 3
        private const val OVERLAY_COOLDOWN_MS = 10 * 60_000L
    }
}
