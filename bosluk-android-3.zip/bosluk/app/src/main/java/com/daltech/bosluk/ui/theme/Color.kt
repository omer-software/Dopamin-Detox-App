package com.daltech.bosluk.ui.theme

import androidx.compose.ui.graphics.Color

val Paper      = Color(0xFFE7E2D6)
val PaperCard  = Color(0xFFF1ECDF)
val Paper2     = Color(0xFFDED8C9)
val Ink        = Color(0xFF20302A)
val Moss       = Color(0xFF57724F)
val MossDeep   = Color(0xFF3F5539)
val Brass      = Color(0xFFB3892F)
val Fade       = Color(0xFF8A8474)
val LineColor  = Color(0xFFC7C0B0)
val Danger     = Color(0xFF9A5A44)
