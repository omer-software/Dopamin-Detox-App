package com.daltech.bosluk.usage

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import com.daltech.bosluk.R

/**
 * Ekran süresi hedefi aşıldığında başka bir uygulamanın üzerine çıkan
 * müdahale (yavaşlatma) popup'ı. SYSTEM_ALERT_WINDOW izni gerektirir.
 */
object OverlayController {

    private var container: View? = null
    private var wm: WindowManager? = null

    fun canDrawOverlays(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun isShowing(): Boolean = container != null

    fun show(
        ctx: Context,
        appLabel: String,
        message: String,
        onContinueAnyway: () -> Unit,
        onOpenBosluk: () -> Unit
    ) {
        if (container != null) return
        if (!canDrawOverlays(ctx)) return

        val wmLocal = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = LayoutInflater.from(ctx).inflate(R.layout.overlay_intervention, null)

        view.findViewById<TextView>(R.id.overlayTitle).text = "$appLabel yerine…"
        view.findViewById<TextView>(R.id.overlayMessage).text = message
        view.findViewById<Button>(R.id.overlayContinueBtn).setOnClickListener {
            dismiss(); onContinueAnyway()
        }
        view.findViewById<Button>(R.id.overlayOpenBtn).setOnClickListener {
            dismiss(); onOpenBosluk()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            wmLocal.addView(view, params)
            container = view
            wm = wmLocal
        } catch (e: Exception) {
            container = null; wm = null
        }
    }

    fun dismiss() {
        try {
            container?.let { wm?.removeView(it) }
        } catch (_: Exception) { }
        container = null
        wm = null
    }
}
