package com.daltech.bosluk.data

import android.content.Context
import com.daltech.bosluk.data.db.AppDatabase
import com.daltech.bosluk.data.db.AppExcuseEntity
import com.daltech.bosluk.data.db.DailyLogEntity
import com.daltech.bosluk.data.db.ProfileEntity
import com.daltech.bosluk.usage.ScreenTimeReader
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class BoslukRepository(private val ctx: Context) {

    private val db = AppDatabase.get(ctx)
    private val profileDao = db.profileDao()
    private val excuseDao = db.appExcuseDao()
    private val logDao = db.dailyLogDao()

    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    fun todayStr(): String = dateFmt.format(Date())
    private fun yesterdayStr(): String = dateFmt.format(Date(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1)))

    // ---- profil ----
    suspend fun getProfile(): ProfileEntity = profileDao.get() ?: ProfileEntity()
    suspend fun saveProfile(p: ProfileEntity) = profileDao.upsert(p)

    fun weightsFromJson(json: String): MutableMap<String, Double> {
        val m = mutableMapOf<String, Double>()
        try {
            val o = JSONObject(json)
            o.keys().forEach { k -> m[k] = o.getDouble(k) }
        } catch (_: Exception) { /* boş başla */ }
        return m
    }

    fun weightsToJson(weights: Map<String, Double>): String {
        val o = JSONObject()
        weights.forEach { (k, v) -> o.put(k, v) }
        return o.toString()
    }

    fun csvToSet(csv: String): Set<String> = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    fun setToCsv(s: Set<String>): String = s.joinToString(",")

    // ---- uygulama mazeretleri ----
    suspend fun getExcuses(): List<AppExcuseEntity> = excuseDao.getAll()
    suspend fun setExcuse(pkg: String, label: String, isWork: Boolean) =
        excuseDao.upsert(AppExcuseEntity(pkg, label, isWork))

    // ---- günlük loglar ----
    suspend fun getLog(date: String): DailyLogEntity? = logDao.getByDate(date)
    suspend fun saveLog(log: DailyLogEntity) = logDao.upsert(log)

    suspend fun recordQuestResult(completed: Boolean, xp: Int) {
        val date = todayStr()
        val current = logDao.getByDate(date) ?: DailyLogEntity(date = date)
        val updated = if (completed)
            current.copy(questsCompleted = current.questsCompleted + 1, xpEarned = current.xpEarned + xp)
        else
            current.copy(questsSkipped = current.questsSkipped + 1)
        logDao.upsert(updated)
    }

    /** Bugünün ekran süresini gerçek kullanım verisinden alıp log'a yazar. */
    suspend fun syncTodayScreenTime() {
        val date = todayStr()
        val minutes = ScreenTimeReader.todayTotalMinutes(ctx)
        val current = logDao.getByDate(date) ?: DailyLogEntity(date = date)
        logDao.upsert(current.copy(screenTimeMinutes = minutes))
    }

    /**
     * Gün değiştiyse: dünün ekran süresini kesinleştirir (varsa) ve
     * dünün log'unun aiSummary'si boşsa true döner (çağıran taraf Gemini'yi tetikler).
     */
    suspend fun rolloverIfNewDay(profile: ProfileEntity): Boolean {
        val today = todayStr()
        if (profile.lastOpenDate == today) return false
        val yDate = yesterdayStr()
        val existing = logDao.getByDate(yDate)
        val needsSummary = existing != null && existing.aiSummary.isNullOrBlank() &&
            (existing.questsCompleted + existing.questsSkipped + existing.screenTimeMinutes) > 0
        saveProfile(profile.copy(lastOpenDate = today, streak = if (existing != null) profile.streak + 1 else 1))
        return needsSummary
    }

    suspend fun reset() {
        profileDao.clear(); excuseDao.clear(); logDao.clear()
    }
}
