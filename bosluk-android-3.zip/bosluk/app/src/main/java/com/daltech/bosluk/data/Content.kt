package com.daltech.bosluk.data

data class Hobby(val id: String, val label: String, val icon: String)
data class Trigger(val id: String, val label: String, val icon: String, val packages: List<String> = emptyList())

data class QuestTemplate(
    val id: Int,
    val title: String,
    val desc: String,
    val tags: List<String>,
    val xp: Int,
    val dur: String,
    val diff: String
)

enum class QuestStatus { OPEN, COMPLETED, SKIPPED }
data class FeedItem(val quest: QuestTemplate, val status: QuestStatus = QuestStatus.OPEN)

object Content {

    val hobbies = listOf(
        Hobby("muzik", "Müzik", "🎵"),
        Hobby("spor", "Spor", "🏃"),
        Hobby("kitap", "Okuma", "📖"),
        Hobby("cizim", "Çizim", "✏️"),
        Hobby("kod", "Kod / Maker", "⚙️"),
        Hobby("doga", "Doğa", "🌿"),
        Hobby("yemek", "Mutfak", "🍳"),
        Hobby("yazi", "Yazı", "🖋️"),
    )

    // packages: bu tetikleyicinin izleyeceği uygulama paket adları
    val triggers = listOf(
        Trigger("ig_scroll", "Sonsuz scroll", "📱",
            listOf("com.instagram.android", "com.zhiliaoapp.musically", "com.twitter.android", "com.facebook.katana")),
        Trigger("gece", "Gece uykusuzluğu", "🌙", emptyList()),
        Trigger("youtube", "YouTube tavşan deliği", "📺", listOf("com.google.android.youtube")),
        Trigger("sabah", "Sabah ilk iş telefon", "⏰", emptyList()),
        Trigger("oyun", "Oyun döngüsü", "🎮", emptyList()),
    )

    val quests = listOf(
        QuestTemplate(1, "Bir enstrümanla 10 dakika", "Metronom yok, hedef yok. Sadece ses çıkar ve dinle.", listOf("muzik"), 40, "10 dk", "kolay"),
        QuestTemplate(2, "Hiç dinlemediğin bir albüm keşfet", "Baştan sona, atlamadan. Kapağını da incele.", listOf("muzik", "gece"), 55, "35 dk", "orta"),
        QuestTemplate(3, "Kısa yürüyüş, kulaklık yok", "5 dakikalık tur. Duyduğun 3 sesi say.", listOf("doga", "ig_scroll", "sabah"), 45, "8 dk", "kolay"),
        QuestTemplate(4, "Bir sayfa oku, sonra kapat", "Sadece bir sayfa. Devamı gelirse bonus.", listOf("kitap", "gece", "youtube"), 35, "6 dk", "kolay"),
        QuestTemplate(5, "Gördüğün ilk nesneyi çiz", "Kötü olması serbest. Amaç bakmak, çizmek değil.", listOf("cizim", "ig_scroll"), 50, "12 dk", "orta"),
        QuestTemplate(6, "20 satır kodu yorumla", "Eski bir projeni aç, ne yaptığını kendine anlat.", listOf("kod", "oyun"), 60, "15 dk", "orta"),
        QuestTemplate(7, "Telefonsuz kahvaltı", "Ekran masada değil. Sadece tabak ve sen.", listOf("sabah", "yemek", "ig_scroll"), 50, "20 dk", "orta"),
        QuestTemplate(8, "Basit bir şey pişir", "3 malzemeyi geçme. Tarif ezberden.", listOf("yemek"), 55, "25 dk", "orta"),
        QuestTemplate(9, "3 cümle serbest yaz", "Bugünü, aklını ya da hiçbir şeyi. Sadece 3 cümle.", listOf("yazi", "gece", "youtube"), 35, "5 dk", "kolay"),
        QuestTemplate(10, "Ekran yerine pencere", "Telefonu uzat, 2 dakika sadece dışarı bak.", listOf("ig_scroll", "gece", "doga", "sabah"), 30, "2 dk", "kolay"),
        QuestTemplate(11, "10 şınav / 10 squat", "Nerede olursan. Sayınca biter.", listOf("spor", "oyun"), 40, "4 dk", "kolay"),
        QuestTemplate(12, "Esneme + nefes", "5 derin nefes, boyun ve omuz. Telefon uzakta.", listOf("spor", "gece", "sabah"), 35, "6 dk", "kolay"),
        QuestTemplate(13, "Bir şeyi tamir et / topla", "Masandaki en dağınık köşe. Sadece o köşe.", listOf("kod", "yemek", "oyun"), 45, "10 dk", "orta"),
    )

    fun hobby(id: String) = hobbies.firstOrNull { it.id == id }
    fun trigger(id: String) = triggers.firstOrNull { it.id == id }

    fun microQuestForPackage(pkg: String): QuestTemplate? {
        val trig = triggers.firstOrNull { pkg in it.packages } ?: return null
        return quests.filter { trig.id in it.tags }.minByOrNull { it.xp }
    }

    val watchedPackages: List<String> = triggers.flatMap { it.packages }.distinct()

    // ekran süresi analizinde göz ardı edilecek sistem/launcher paketleri (kaba filtre)
    val ignoredPrefixes = listOf(
        "com.android.", "com.google.android.inputmethod", "com.google.android.gms",
        "com.google.android.apps.nexuslauncher", "com.sec.android.app.launcher",
        "com.daltech.bosluk"
    )
}
