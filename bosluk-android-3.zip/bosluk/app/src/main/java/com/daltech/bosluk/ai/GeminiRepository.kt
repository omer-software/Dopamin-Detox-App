package com.daltech.bosluk.ai

import com.daltech.bosluk.data.Content
import com.daltech.bosluk.usage.AppUsageInfo
import org.json.JSONObject
import kotlin.random.Random

data class DetoxPlan(val planText: String, val dailyGoalMinutes: Int)

object GeminiRepository {

    /** Kurulumda: kullanıcı verisini analiz edip kişisel bir detoks planı üretir. */
    suspend fun generateDetoxPlan(
        name: String,
        screenTimeTodayMin: Int,
        topApps: List<AppUsageInfo>,
        workExcusedPackages: Set<String>,
        hobbies: Set<String>,
        triggers: Set<String>,
    ): DetoxPlan {
        val hobbyLabels = hobbies.mapNotNull { Content.hobby(it)?.label }.joinToString(", ")
        val triggerLabels = triggers.mapNotNull { Content.trigger(it)?.label }.joinToString(", ")
        val appLines = topApps.joinToString("\n") { app ->
            val excuse = if (app.packageName in workExcusedPackages) " (kullanıcı: iş için kullanıyorum diyor)" else ""
            "- ${app.label}: günde ${app.minutes} dk$excuse"
        }

        val prompt = """
            Sen bir dopamin detoksu koçusun. Kullanıcının gerçek verilerine göre KISA, samimi, motive edici
            ve UYGULANABİLİR bir plan yaz. Kısıtlama değil, yönlendirme mantığıyla konuş.

            Kullanıcı: $name
            Bugünkü toplam ekran süresi: $screenTimeTodayMin dakika
            En çok kullanılan uygulamalar:
            $appLines

            Sevdiği hobiler: $hobbyLabels
            Dikkatinin dağıldığı anlar: $triggerLabels

            Not: "iş için kullanıyorum" diyen uygulamaları hedef alma, onları normal kabul et.

            SADECE şu JSON formatında yanıt ver, başka hiçbir şey yazma:
            {"plan": "3-5 cümlelik Türkçe plan metni, ikinci tekil şahısla (sen dilinde)", "daily_goal_minutes": <mevcut kullanımın biraz altında, makul bir hedef, tam sayı>}
        """.trimIndent()

        val raw = GeminiClient.generate(prompt)
        val parsed = raw?.let { parsePlanJson(it) }
        return parsed ?: fallbackPlan(name, screenTimeTodayMin)
    }

    /** Gün sonu: o günün verileriyle kısa bir özet/yorum üretir. */
    suspend fun generateDailySummary(
        name: String,
        screenTimeMin: Int,
        goalMin: Int,
        questsCompleted: Int,
        questsSkipped: Int,
        xpEarned: Int
    ): String {
        val prompt = """
            Sen bir dopamin detoksu koçusun. $name için dünün kısa bir özetini yaz (2-3 cümle, Türkçe, sen dilinde, samimi).
            Dün ekran süresi: $screenTimeMin dk (hedef: $goalMin dk)
            Tamamlanan quest: $questsCompleted, atlanan: $questsSkipped, kazanılan odak puanı: $xpEarned
            Eleştirmeden, yargılamadan; ilerlemeyi öv, geride kalınan yeri nazikçe işaret et.
            SADECE özet metni yaz, başlık veya JSON kullanma.
        """.trimIndent()

        return GeminiClient.generate(prompt) ?: fallbackSummary(screenTimeMin, goalMin, questsCompleted)
    }

    /** Overlay popup'ı için kısa motivasyon mesajı. */
    suspend fun motivationalMessage(appLabel: String, overMinutes: Int): String {
        val prompt = """
            Kullanıcı bugünkü ekran süresi hedefini $overMinutes dakika aştı ve şimdi "$appLabel" uygulamasını açıyor.
            Tek cümlelik, yargılamayan, sıcak ama düşündürücü bir Türkçe mesaj yaz (max 18 kelime).
            Sadece cümleyi yaz, tırnak veya başlık kullanma.
        """.trimIndent()
        return GeminiClient.generate(prompt) ?: fallbackMotivational()
    }

    // ---- yerel yedekler (key yoksa / ağ hatasında asla boş kalmasın) ----

    private fun parsePlanJson(raw: String): DetoxPlan? = try {
        val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val json = JSONObject(cleaned)
        val plan = json.optString("plan")
        if (plan.isBlank()) return null
        val goal = json.optInt("daily_goal_minutes", 90).coerceIn(15, 600)
        DetoxPlan(plan, goal)
    } catch (e: Exception) {
        null
    }

    private fun fallbackPlan(name: String, screenTimeTodayMin: Int): DetoxPlan {
        val goal = (screenTimeTodayMin * 0.8).toInt().coerceAtLeast(30)
        return DetoxPlan(
            "$name, bugünden başlıyoruz. Seni kısıtlamayacağız — dikkatinin dağıldığı anlarda " +
                "sana uygun küçük quest'ler önereceğiz. İlk hedef: günlük ekran süreni $goal dakikaya indirmek, yavaş yavaş.",
            goal
        )
    }

    private fun fallbackSummary(screenTimeMin: Int, goalMin: Int, completed: Int): String =
        if (screenTimeMin <= goalMin)
            "Dün hedefinin altında kaldın ve $completed quest tamamladın — güzel bir gündü."
        else
            "Dün hedefi biraz aştın ama $completed quest tamamladın, bu da sayılır. Bugün tekrar deneyelim."

    private val fallbackLines = listOf(
        "Bir dakika dur — bu quest bekliyor, önce ona bak ister misin?",
        "Ekran zaten hedefini geçti. Şimdi 2 dakika pencereye bakmaya ne dersin?",
        "Buraya gelmeden önce bir nefes al. Devam etmek istiyor musun gerçekten?",
        "Defterindeki bir quest hâlâ açık. Ona 5 dakika versen?",
    )
    private fun fallbackMotivational(): String = fallbackLines[Random.nextInt(fallbackLines.size)]
}
