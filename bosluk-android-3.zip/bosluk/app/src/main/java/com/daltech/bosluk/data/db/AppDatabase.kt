package com.daltech.bosluk.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ProfileEntity::class, AppExcuseEntity::class, DailyLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun appExcuseDao(): AppExcuseDao
    abstract fun dailyLogDao(): DailyLogDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(ctx: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    ctx.applicationContext, AppDatabase::class.java, "bosluk.db"
                ).build().also { instance = it }
            }
    }
}
