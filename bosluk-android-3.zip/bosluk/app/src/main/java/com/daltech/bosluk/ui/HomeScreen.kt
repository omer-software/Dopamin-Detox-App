package com.daltech.bosluk.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daltech.bosluk.HomeState
import com.daltech.bosluk.data.Content
import com.daltech.bosluk.data.FeedItem
import com.daltech.bosluk.data.QuestStatus
import com.daltech.bosluk.data.QuestTemplate
import com.daltech.bosluk.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    state: HomeState,
    onGrantUsageAccess: () -> Unit,
    onGrantOverlay: () -> Unit,
    onComplete: (FeedItem) -> Unit,
    onSkip: (FeedItem) -> Unit,
    onDefer: (FeedItem) -> Unit,
    onReset: () -> Unit,
    onToastShown: () -> Unit,
    onDismissSummary: () -> Unit,
) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.toast) { state.toast?.let { snackbar.showSnackbar(it); onToastShown() } }

    Scaffold(containerColor = Paper, snackbarHost = { SnackbarHost(snackbar) }) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).padding(horizontal = 22.dp),
            contentPadding = PaddingValues(top = 26.dp, bottom = 30.dp)
        ) {
            item { Header(state) }

            state.yesterdaySummary?.let { summary ->
                item { YesterdayCard(summary, onDismissSummary) }
            }

            item { ScreenTimeCard(state) }

            if (!state.usageAccessGranted) item { PermBanner(
                title = "Ekran süresi izni gerekiyor",
                body = "Gerçek verini görebilmemiz için Kullanım erişimi izni ver.",
                cta = "Ayarları aç", onClick = onGrantUsageAccess
            ) }
            if (state.usageAccessGranted && !state.overlayPermGranted) item { PermBanner(
                title = "Anlık müdahaleyi aç",
                body = "Hedefini aştığında seni yavaşlatan bir hatırlatma göstermemiz için “diğer uygulamaların üzerinde göster” izni gerekiyor.",
                cta = "İzin ver", onClick = onGrantOverlay
            ) }

            if (state.topApps.isNotEmpty()) item { TopAppsCard(state) }

            item { StatsRow(state) }

            item {
                Text(
                    if (state.openCount > 0) "${state.openCount} QUEST BEKLİYOR" else "GÜN TAMAM",
                    color = Moss, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                    letterSpacing = 2.sp, modifier = Modifier.padding(top = 22.dp, bottom = 12.dp)
                )
            }
            if (state.openCount == 0) item { EmptyState() }

            items(state.feed, key = { it.quest.id }) { item ->
                QuestCard(item, state, onComplete, onSkip, onDefer)
                Spacer(Modifier.height(14.dp))
            }

            item {
                TextButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) {
                    Text("Kurulumu sıfırla", color = Fade)
                }
            }
        }
    }
}

@Composable
private fun Header(state: HomeState) {
    val today = remember { SimpleDateFormat("EEEE, d MMMM", Locale("tr")).format(Date()) }
    Column {
        Text("Merhaba, ${state.greetingName}", style = MaterialTheme.typography.headlineMedium, color = Ink)
        Text(today.uppercase(Locale("tr")), color = Fade, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
            letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun YesterdayCard(summary: String, onDismiss: () -> Unit) {
    Column(
        Modifier.padding(top = 18.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(PaperCard).border(BorderStroke(1.dp, LineColor), RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("DÜNÜN ÖZETİ", color = Moss, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, letterSpacing = 1.sp)
            Text("kapat", color = Fade, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onDismiss))
        }
        Spacer(Modifier.height(8.dp))
        Text(summary, color = Ink, fontSize = 14.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun ScreenTimeCard(state: HomeState) {
    val over = state.screenTimeMin > state.goalMin
    val progress = (state.screenTimeMin.toFloat() / state.goalMin.toFloat()).coerceIn(0f, 1.5f)
    Column(
        Modifier.padding(top = 18.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(PaperCard).border(BorderStroke(1.dp, LineColor), RoundedCornerShape(16.dp)).padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${state.screenTimeMin}", fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 34.sp,
                color = if (over) Danger else MossDeep)
            Text(" dk", color = Fade, fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp, start = 2.dp))
            Spacer(Modifier.weight(1f))
            Text("hedef: ${state.goalMin} dk", color = Fade, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { (progress / 1.5f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = if (over) Danger else Moss, trackColor = Paper2,
        )
        if (over) {
            Spacer(Modifier.height(8.dp))
            Text("Hedefi ${state.screenTimeMin - state.goalMin} dk aştın. Olsun, yarın yeniden.", color = Danger, fontSize = 12.5.sp)
        }
    }
}

@Composable
private fun TopAppsCard(state: HomeState) {
    Column(Modifier.padding(top = 14.dp).fillMaxWidth()) {
        Text("BUGÜN EN ÇOK KULLANDIKLARIN", color = Fade, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        state.topApps.take(4).forEach { app ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(app.label, color = Ink, fontSize = 13.5.sp, modifier = Modifier.weight(1f))
                Text("${app.minutes} dk", color = Fade, fontFamily = FontFamily.Monospace, fontSize = 12.5.sp)
            }
        }
    }
}

@Composable
private fun PermBanner(title: String, body: String, cta: String, onClick: () -> Unit) {
    Column(
        Modifier.padding(top = 14.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFEFE3CE)).border(BorderStroke(1.dp, Brass.copy(alpha = 0.4f)), RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Text(title, fontFamily = FontFamily.Serif, fontSize = 16.sp, color = Ink)
        Text(body, color = Fade, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        Button(onClick = onClick, shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Brass, contentColor = Color.White)) { Text(cta) }
    }
}

@Composable
private fun StatsRow(state: HomeState) {
    Column(Modifier.padding(top = 20.dp)) {
        HorizontalDivider(color = LineColor)
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Stat(state.streak.toString(), "gün seri")
            Stat(state.xp.toString(), "odak puanı")
            Stat(state.level.toString(), "seviye")
        }
        HorizontalDivider(color = LineColor)
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column {
        Text(value, fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, color = MossDeep)
        Text(label.uppercase(), color = Fade, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun QuestCard(item: FeedItem, state: HomeState, onComplete: (FeedItem) -> Unit, onSkip: (FeedItem) -> Unit, onDefer: (FeedItem) -> Unit) {
    val q = item.quest
    val completed = item.status == QuestStatus.COMPLETED
    if (item.status == QuestStatus.SKIPPED) return

    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PaperCard)
            .border(BorderStroke(1.dp, LineColor), RoundedCornerShape(16.dp)).padding(18.dp)
            .then(if (completed) Modifier.alpha(0.55f) else Modifier)
    ) {
        Column {
            Text(reasonLine(q, state), color = Moss, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, letterSpacing = 0.5.sp)
            Spacer(Modifier.height(9.dp))
            Text(q.title, style = MaterialTheme.typography.titleLarge, color = Ink)
            Spacer(Modifier.height(8.dp))
            Text(q.desc, color = Fade, fontSize = 13.5.sp, lineHeight = 19.sp)
            Spacer(Modifier.height(13.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetaTag(q.dur); MetaTag(q.diff); MetaTag("+${q.xp} odak", reward = true)
            }
            if (completed) {
                Spacer(Modifier.height(12.dp))
                Text("TAMAM ✓", color = Moss, fontFamily = FontFamily.Monospace, fontSize = 13.sp, letterSpacing = 2.sp)
            } else {
                Spacer(Modifier.height(15.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    CardAction("Tamamla", Modifier.weight(1.6f), filled = true) { onComplete(item) }
                    CardAction("Atla", Modifier.weight(0.9f)) { onSkip(item) }
                    CardAction("Ertele", Modifier.weight(0.9f)) { onDefer(item) }
                }
            }
        }
    }
}

@Composable
private fun MetaTag(text: String, reward: Boolean = false) {
    Text(text, color = if (reward) Color(0xFF7A5B15) else MossDeep, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(if (reward) Brass.copy(alpha = 0.16f) else Paper2)
            .padding(horizontal = 9.dp, vertical = 4.dp))
}

@Composable
private fun CardAction(text: String, modifier: Modifier, filled: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp)).background(if (filled) Moss else Color.Transparent)
            .border(BorderStroke(1.dp, if (filled) Moss else LineColor), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick).padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (filled) Paper else Ink, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun EmptyState() {
    Column(Modifier.fillMaxWidth().padding(vertical = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Defter bugünlük dolu.", fontFamily = FontFamily.Serif, fontSize = 22.sp, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text("Yarın profiline göre yenileri gelecek. Şimdi telefonu bırakma sırası sende.",
            color = Fade, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

private fun reasonLine(q: QuestTemplate, state: HomeState): String {
    val active = state.hobbies + state.triggers
    val t = q.tags.firstOrNull { it in active } ?: return "· SANA GÖRE"
    Content.hobby(t)?.let { return "· ${it.label} sevdiğin için".uppercase(Locale("tr")) }
    Content.trigger(t)?.let { return "· ${it.label} anına karşı".uppercase(Locale("tr")) }
    return "· SANA GÖRE"
}
