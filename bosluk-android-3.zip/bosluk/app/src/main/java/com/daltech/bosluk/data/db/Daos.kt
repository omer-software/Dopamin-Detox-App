package com.daltech.bosluk.data.db

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profile WHERE id = 0 LIMIT 1")
    suspend fun get(): ProfileEntity?

    @Query("SELECT * FROM profile WHERE id = 0 LIMIT 1")
    fun observe(): Flow<ProfileEntity?>

    @Upsert
    suspend fun upsert(profile: ProfileEntity)

    @Query("DELETE FROM profile")
    suspend fun clear()
}

@Dao
interface AppExcuseDao {
    @Query("SELECT * FROM app_excuses ORDER BY label")
    fun observeAll(): Flow<List<AppExcuseEntity>>

    @Query("SELECT * FROM app_excuses")
    suspend fun getAll(): List<AppExcuseEntity>

    @Upsert
    suspend fun upsert(entity: AppExcuseEntity)

    @Query("DELETE FROM app_excuses")
    suspend fun clear()
}

@Dao
interface DailyLogDao {
    @Query("SELECT * FROM daily_logs WHERE date = :date LIMIT 1")
    suspend fun getByDate(date: String): DailyLogEntity?

    @Query("SELECT * FROM daily_logs ORDER BY date DESC LIMIT :limit")
    suspend fun recent(limit: Int = 7): List<DailyLogEntity>

    @Upsert
    suspend fun upsert(log: DailyLogEntity)

    @Query("DELETE FROM daily_logs")
    suspend fun clear()
}
