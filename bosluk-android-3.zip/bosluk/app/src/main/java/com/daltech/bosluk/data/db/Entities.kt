package com.daltech.bosluk.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Tek satırlık profil tablosu (id sabit 0). Ad, kullanıcı adı, hedef,
 * Gemini'nin ürettiği plan metni ve quest ağırlıkları (JSON) burada tutulur.
 */
@Entity(tableName = "profile")
data class ProfileEntity(
    @PrimaryKey val id: Int = 0,
    val fullName: String = "",
    val username: String = "",
    val onboarded: Boolean = false,
    val hobbiesCsv: String = "",       // "muzik,spor"
    val triggersCsv: String = "",      // "ig_scroll,gece"
    val weightsJson: String = "{}",    // tag -> ağırlık
    val dailyGoalMinutes: Int = 90,
    val planText: String = "",
    val xp: Int = 0,
    val streak: Int = 1,
    val lastOpenDate: String = "",     // "yyyy-MM-dd" — gün değişimini tespit için
    val overlayDismissedUntilEpochMin: Long = 0L // müdahale popup cooldown
)

/** Kurulumda işaretlenen "iş için kullanıyorum" mazeretli uygulamalar. */
@Entity(tableName = "app_excuses")
data class AppExcuseEntity(
    @PrimaryKey val packageName: String,
    val label: String,
    val isWorkExcuse: Boolean
)

/** Gün bazlı özet: ekran süresi, quest sonuçları, AI günü özeti. */
@Entity(tableName = "daily_logs")
data class DailyLogEntity(
    @PrimaryKey val date: String,       // "yyyy-MM-dd"
    val screenTimeMinutes: Int = 0,
    val questsCompleted: Int = 0,
    val questsSkipped: Int = 0,
    val xpEarned: Int = 0,
    val aiSummary: String? = null
)
