package com.daltech.bosluk

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daltech.bosluk.ai.DetoxPlan
import com.daltech.bosluk.ai.GeminiRepository
import com.daltech.bosluk.data.BoslukRepository
import com.daltech.bosluk.data.FeedItem
import com.daltech.bosluk.data.QuestEngine
import com.daltech.bosluk.data.QuestStatus
import com.daltech.bosluk.data.db.DailyLogEntity
import com.daltech.bosluk.data.db.ProfileEntity
import com.daltech.bosluk.usage.AppUsageInfo
import com.daltech.bosluk.usage.ScreenTimeReader
import com.daltech.bosluk.usage.UsageTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class OnboardingState(
    val step: Int = 1,                 // 1 ad-soyad, 2 ekran süresi, 3 hobi, 4 tetikleyici, 5 plan, 6 kullanıcı adı
    val name: String = "",
    val usageAccessGranted: Boolean = false,
    val loadingUsage: Boolean = false,
    val screenTimeMin: Int = 0,
    val topApps: List<AppUsageInfo> = emptyList(),
    val excuses: Map<String, Boolean> = emptyMap(),
    val hobbies: Set<String> = emptySet(),
    val triggers: Set<String> = emptySet(),
    val planLoading: Boolean = false,
    val plan: DetoxPlan? = null,
    val username: String = "",
)

data class HomeState(
    val greetingName: String = "",
    val screenTimeMin: Int = 0,
    val goalMin: Int = 90,
    val topApps: List<AppUsageInfo> = emptyList(),
    val hobbies: Set<String> = emptySet(),
    val triggers: Set<String> = emptySet(),
    val feed: List<FeedItem> = emptyList(),
    val xp: Int = 0,
    val streak: Int = 1,
    val toast: String? = null,
    val yesterdaySummary: String? = null,
    val usageAccessGranted: Boolean = false,
    val overlayPermGranted: Boolean = false,
) {
    val level: Int get() = xp / 150 + 1
    val openCount: Int get() = feed.count { it.status == QuestStatus.OPEN }
}

data class UiState(
    val loading: Boolean = true,
    val onboarded: Boolean = false,
    val onboarding: OnboardingState = OnboardingState(),
    val home: HomeState = HomeState(),
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx get() = getApplication<Application>()
    private val repo = BoslukRepository(ctx)
    private lateinit var engine: QuestEngine
    private var profile = ProfileEntity()

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            profile = repo.getProfile()
            if (profile.onboarded) {
                loadHome()
            } else {
                _ui.value = UiState(loading = false, onboarded = false)
            }
        }
    }

    // =========================================================
    // ONBOARDING
    // =========================================================

    fun obSetName(name: String) = _ui.update { it.copy(onboarding = it.onboarding.copy(name = name)) }

    fun obGoToScreenTime() {
        _ui.update { it.copy(onboarding = it.onboarding.copy(step = 2, loadingUsage = true)) }
        viewModelScope.launch {
            val granted = UsageTracker.hasUsageAccess(ctx)
            if (granted) {
                val (minutes, apps) = withContext(Dispatchers.IO) {
                    ScreenTimeReader.todayTotalMinutes(ctx) to ScreenTimeReader.topAppsToday(ctx, 6)
                }
                _ui.update {
                    it.copy(onboarding = it.onboarding.copy(
                        usageAccessGranted = true, loadingUsage = false,
                        screenTimeMin = minutes, topApps = apps,
                        excuses = apps.associate { a -> a.packageName to false }
                    ))
                }
            } else {
                _ui.update { it.copy(onboarding = it.onboarding.copy(usageAccessGranted = false, loadingUsage = false)) }
            }
        }
    }

    /** Kullanım erişimi ayarlardan verildikten sonra ekrana dönünce yeniden dener. */
    fun obRecheckUsageAccess() = obGoToScreenTime()

    fun obToggleExcuse(pkg: String) = _ui.update { s ->
        val cur = s.onboarding.excuses[pkg] ?: false
        s.copy(onboarding = s.onboarding.copy(excuses = s.onboarding.excuses + (pkg to !cur)))
    }

    fun obGoToHobby() = _ui.update { it.copy(onboarding = it.onboarding.copy(step = 3)) }

    fun obToggleHobby(id: String) = _ui.update { s ->
        s.copy(onboarding = s.onboarding.copy(hobbies = s.onboarding.hobbies.toggle(id)))
    }

    fun obGoToTrigger() = _ui.update { it.copy(onboarding = it.onboarding.copy(step = 4)) }

    fun obToggleTrigger(id: String) = _ui.update { s ->
        s.copy(onboarding = s.onboarding.copy(triggers = s.onboarding.triggers.toggle(id)))
    }

    fun obGoToPlan() {
        _ui.update { it.copy(onboarding = it.onboarding.copy(step = 5, planLoading = true)) }
        viewModelScope.launch {
            val ob = _ui.value.onboarding
            val workExcused = ob.excuses.filterValues { it }.keys
            val plan = GeminiRepository.generateDetoxPlan(
                name = ob.name.ifBlank { "arkadaşım" },
                screenTimeTodayMin = ob.screenTimeMin,
                topApps = ob.topApps,
                workExcusedPackages = workExcused,
                hobbies = ob.hobbies,
                triggers = ob.triggers
            )
            _ui.update { it.copy(onboarding = it.onboarding.copy(planLoading = false, plan = plan)) }
        }
    }

    fun obGoToUsername() = _ui.update { it.copy(onboarding = it.onboarding.copy(step = 6)) }
    fun obSetUsername(u: String) = _ui.update { it.copy(onboarding = it.onboarding.copy(username = u)) }

    fun obFinish() {
        viewModelScope.launch {
            val ob = _ui.value.onboarding
            val weights = mutableMapOf<String, Double>()
            (ob.hobbies + ob.triggers).forEach { weights[it] = 1.0 }

            // uygulama mazeretlerini kaydet
            ob.topApps.forEach { app ->
                repo.setExcuse(app.packageName, app.label, ob.excuses[app.packageName] ?: false)
            }

            profile = ProfileEntity(
                fullName = ob.name,
                username = ob.username.ifBlank { ob.name },
                onboarded = true,
                hobbiesCsv = repo.setToCsv(ob.hobbies),
                triggersCsv = repo.setToCsv(ob.triggers),
                weightsJson = repo.weightsToJson(weights),
                dailyGoalMinutes = ob.plan?.dailyGoalMinutes ?: 90,
                planText = ob.plan?.planText ?: "",
                xp = 0, streak = 1,
                lastOpenDate = repo.todayStr()
            )
            repo.saveProfile(profile)
            loadHome()
        }
    }

    // =========================================================
    // HOME
    // =========================================================

    private suspend fun loadHome() {
        engine = QuestEngine(
            repo.csvToSet(profile.hobbiesCsv),
            repo.csvToSet(profile.triggersCsv),
            repo.weightsFromJson(profile.weightsJson)
        )

        // gün değiştiyse: streak güncelle + gerekiyorsa gün-sonu özeti üret
        val needsSummary = repo.rolloverIfNewDay(profile)
        profile = repo.getProfile()

        withContext(Dispatchers.IO) { repo.syncTodayScreenTime() }
        val todayLog = repo.getLog(repo.todayStr())
        val screenMin = withContext(Dispatchers.IO) { ScreenTimeReader.todayTotalMinutes(ctx) }
        val topApps = withContext(Dispatchers.IO) { ScreenTimeReader.topAppsToday(ctx, 5) }

        var yesterdaySummary: String? = null
        if (needsSummary) {
            val yLog = repo.getLog(previousDateStr())
            if (yLog != null) {
                val summary = GeminiRepository.generateDailySummary(
                    name = profile.username.ifBlank { profile.fullName },
                    screenTimeMin = yLog.screenTimeMinutes,
                    goalMin = profile.dailyGoalMinutes,
                    questsCompleted = yLog.questsCompleted,
                    questsSkipped = yLog.questsSkipped,
                    xpEarned = yLog.xpEarned
                )
                repo.saveLog(yLog.copy(aiSummary = summary))
                yesterdaySummary = summary
            }
        }

        _ui.value = UiState(
            loading = false, onboarded = true,
            home = HomeState(
                greetingName = profile.username.ifBlank { profile.fullName },
                screenTimeMin = screenMin,
                goalMin = profile.dailyGoalMinutes,
                topApps = topApps,
                hobbies = repo.csvToSet(profile.hobbiesCsv),
                triggers = repo.csvToSet(profile.triggersCsv),
                feed = engine.buildFeed(),
                xp = profile.xp, streak = profile.streak,
                yesterdaySummary = yesterdaySummary,
                usageAccessGranted = UsageTracker.hasUsageAccess(ctx),
                overlayPermGranted = android.provider.Settings.canDrawOverlays(ctx)
            )
        )
        val logForToday = todayLog
        if (logForToday == null) repo.saveLog(DailyLogEntity(date = repo.todayStr(), screenTimeMinutes = screenMin))
    }

    private fun previousDateStr(): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(cal.time)
    }

    fun refreshPermissions() = _ui.update { s ->
        s.copy(home = s.home.copy(
            usageAccessGranted = UsageTracker.hasUsageAccess(ctx),
            overlayPermGranted = android.provider.Settings.canDrawOverlays(ctx)
        ))
    }

    fun refreshScreenTime() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.syncTodayScreenTime() }
            val minutes = withContext(Dispatchers.IO) { ScreenTimeReader.todayTotalMinutes(ctx) }
            val apps = withContext(Dispatchers.IO) { ScreenTimeReader.topAppsToday(ctx, 5) }
            _ui.update { it.copy(home = it.home.copy(screenTimeMin = minutes, topApps = apps)) }
        }
    }

    fun complete(item: FeedItem) = updateFeed(item, QuestStatus.COMPLETED) {
        engine.reward(item.quest)
        _ui.update {
            it.copy(home = it.home.copy(
                xp = it.home.xp + item.quest.xp,
                toast = "+${item.quest.xp} odak · bu tür artık daha sık gelecek"
            ))
        }
        profile = profile.copy(xp = profile.xp + item.quest.xp)
        viewModelScope.launch { repo.recordQuestResult(completed = true, xp = item.quest.xp) }
    }

    fun skip(item: FeedItem) = updateFeed(item, QuestStatus.SKIPPED) {
        engine.demote(item.quest)
        _ui.update { it.copy(home = it.home.copy(toast = "Anlaşıldı · bu tür daha az gelecek")) }
        viewModelScope.launch { repo.recordQuestResult(completed = false, xp = 0) }
    }

    fun defer(item: FeedItem) {
        _ui.update { s ->
            val list = s.home.feed.toMutableList()
            list.remove(item); list.add(item)
            s.copy(home = s.home.copy(feed = list, toast = "Ertelendi · günün sonuna alındı"))
        }
    }

    fun clearToast() = _ui.update { it.copy(home = it.home.copy(toast = null)) }
    fun dismissYesterdaySummary() = _ui.update { it.copy(home = it.home.copy(yesterdaySummary = null)) }

    fun reset() {
        viewModelScope.launch {
            repo.reset()
            profile = ProfileEntity()
            _ui.value = UiState(loading = false, onboarded = false)
        }
    }

    // ---- helpers ----
    private inline fun updateFeed(item: FeedItem, status: QuestStatus, after: () -> Unit) {
        _ui.update { s ->
            s.copy(home = s.home.copy(feed = s.home.feed.map {
                if (it.quest.id == item.quest.id) it.copy(status = status) else it
            }))
        }
        after()
        viewModelScope.launch { repo.saveProfile(profile.copy(weightsJson = repo.weightsToJson(engine.weights))) }
    }

    private fun Set<String>.toggle(id: String) = if (contains(id)) this - id else this + id
    private inline fun MutableStateFlow<UiState>.update(block: (UiState) -> UiState) { value = block(value) }
}
