package com.daltech.bosluk.usage

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process

object UsageTracker {

    /** Kullanıcı Ayarlar > Kullanım erişimi'nden bu izni verdi mi? */
    fun hasUsageAccess(ctx: Context): Boolean {
        val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** [sinceMs] içinde, [packages] listesindeki her paketin kaç kez ön plana geldiği. */
    fun foregroundOpenCounts(ctx: Context, packages: List<String>, sinceMs: Long): Map<String, Int> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - sinceMs, now)
        val counts = HashMap<String, Int>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName in packages) {
                counts[e.packageName] = (counts[e.packageName] ?: 0) + 1
            }
        }
        return counts
    }

    /**
     * Son foreground olayı: hangi paket, ne zaman ön plana geldi.
     * Overlay müdahalesi için "az önce hangi app açıldı" tespitinde kullanılır.
     */
    fun lastForegroundEvent(ctx: Context, sinceMs: Long): Pair<String, Long>? {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - sinceMs, now)
        var last: Pair<String, Long>? = null
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                last = e.packageName to e.timeStamp
            }
        }
        return last
    }
}
