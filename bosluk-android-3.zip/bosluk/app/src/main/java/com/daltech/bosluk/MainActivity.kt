package com.daltech.bosluk

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daltech.bosluk.ui.HomeScreen
import com.daltech.bosluk.ui.OnboardingScreen
import com.daltech.bosluk.ui.theme.BoslukTheme
import com.daltech.bosluk.usage.QuestNotifier
import com.daltech.bosluk.usage.TriggerService
import com.daltech.bosluk.usage.UsageTracker

class MainActivity : ComponentActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private lateinit var vm: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        QuestNotifier.ensureChannels(this)
        askNotificationPermission()

        setContent {
            BoslukTheme {
                vm = viewModel()
                val state by vm.ui.collectAsStateWithLifecycle()

                when {
                    state.loading -> LoadingBox()
                    !state.onboarded -> OnboardingScreen(
                        ob = state.onboarding,
                        onSetName = vm::obSetName,
                        onGoScreenTime = vm::obGoToScreenTime,
                        onRecheckUsage = vm::obRecheckUsageAccess,
                        onOpenUsageSettings = { openUsageAccessSettings() },
                        onToggleExcuse = vm::obToggleExcuse,
                        onGoHobby = vm::obGoToHobby,
                        onToggleHobby = vm::obToggleHobby,
                        onGoTrigger = vm::obGoToTrigger,
                        onToggleTrigger = vm::obToggleTrigger,
                        onGoPlan = vm::obGoToPlan,
                        onGoUsername = vm::obGoToUsername,
                        onSetUsername = vm::obSetUsername,
                        onFinish = vm::obFinish,
                        onBack = { }
                    )
                    else -> HomeScreen(
                        state = state.home,
                        onGrantUsageAccess = { openUsageAccessSettings() },
                        onGrantOverlay = { openOverlaySettings() },
                        onComplete = vm::complete,
                        onSkip = vm::skip,
                        onDefer = vm::defer,
                        onReset = vm::reset,
                        onToastShown = vm::clearToast,
                        onDismissSummary = vm::dismissYesterdaySummary
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::vm.isInitialized) {
            vm.refreshPermissions()
            vm.refreshScreenTime()
        }
        if (UsageTracker.hasUsageAccess(this)) startTriggerService()
    }

    private fun startTriggerService() {
        ContextCompat.startForegroundService(this, Intent(this, TriggerService::class.java))
    }

    private fun openUsageAccessSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@Composable
private fun LoadingBox() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}
