# Boşluk — side-questli dopamin detoksu (Android)

Native **Kotlin + Jetpack Compose**. Gerçek ekran süresi verisi + Gemini AI + yerel Room veritabanı.

## Mimari özeti

- **Kurulum (6 adım):** Ad Soyad → gerçek ekran süresi + en çok kullanılan uygulamalar (iş mazereti etiketiyle) → hobiler → hassas noktalar → **Gemini'nin ürettiği kişisel plan** → kullanıcı adı.
- **Ana ekran:** Bugünkü ekran süresi + hedef karşılaştırması, en çok kullanılan uygulamalar, quest defteri, gün seri/odak puanı/seviye.
- **Gün sonu:** Yeni güne girildiğinde dünün verisiyle Gemini'den kısa bir özet üretilip ana ekranda gösterilir.
- **Anlık müdahale:** Günlük hedef aşıldığında ve başka bir uygulama açıldığında, o uygulamanın **üzerine çıkan bir popup** (overlay) Gemini'nin ürettiği (veya yerel yedek) motivasyon cümlesiyle kullanıcıyı yavaşlatır.
- **Veri:** Her şey cihazda — Room (SQLite). Sunucu/Firebase yok.
- **AI:** Gemini Developer API'ye doğrudan REST çağrısı (`gemini-2.5-flash`). Firebase projesi gerekmez, sadece bir API key.

## Kurulum — 3 şey gerekiyor

### 1. Gemini API key (ücretsiz)
1. https://aistudio.google.com/apikey adresine git, ücretsiz key oluştur.
2. Proje kökünde `local.properties.example` dosyasını **`local.properties`** olarak kopyala.
3. İçine key'ini yaz: `GEMINI_API_KEY=AIza...`

`local.properties` `.gitignore`'da — repoya gitmez. Key olmadan da uygulama çöker: Gemini çağrıları başarısız olursa yerel yedek metinlere (sabit plan/özet/motivasyon cümleleri) otomatik düşer, sadece kişiselleştirme kaybolur.

### 2. GitHub Actions ile derliyorsan: repo secret ekle
Ayarlar → Secrets and variables → Actions → **New repository secret**:
- Name: `GEMINI_API_KEY`
- Value: kendi key'in

Workflow bunu otomatik ortam değişkeni olarak Gradle'a geçirir (`build.yml` içinde zaten ayarlı).

### 3. Android Studio ile açma
1. `bosluk` klasörünü Android Studio'da **Open** ile aç (klasörün kendisini, dosya değil).
2. Gradle sync bitsin.
3. `minSdk 26`, `targetSdk 34`.

## Uygulamada verilmesi gereken izinler (ilk açılışta sırayla istenir)
1. **Bildirim izni** — Android 13+.
2. **Kullanım erişimi** (Ayarlar > Kullanım erişimi) — ekran süresi ve en çok kullanılan uygulamalar için. Onboarding'in 2. adımı bunu ister.
3. **Diğer uygulamaların üzerinde göster** (overlay) — ana ekrandaki banner'dan verilir. Anlık müdahale popup'ı için gerekli; verilmezse uygulama normal çalışır, sadece popup gösterilmez.

## Test etme
- **Plan üretimi:** Onboarding'in 5. adımında "Planın hazırlanıyor" ekranı Gemini'yi çağırır. Key yanlışsa/yoksa birkaç saniye içinde yerel yedek plana düşer (hata vermez).
- **Gün sonu özeti:** Cihazın tarihini bir gün ileri alıp uygulamayı açarsan, dünün log'u varsa özet üretilip ana ekranda kart olarak çıkar.
- **Overlay müdahalesi:** `TriggerService.kt`'teki `POLL_MS`, `THRESHOLD`, `OVERLAY_COOLDOWN_MS` değerlerini küçültüp hızlı test edebilirsin. Ana ekrandaki hedefi düşük bir değere ayarlamak (planı düşük hedefle bitirmek) da işe yarar.

## Dosya haritası
```
data/Content.kt          → hobiler, tetikleyiciler (paket adlarıyla), quest havuzu
data/QuestEngine.kt       → puanlama + ağırlık öğrenme
data/BoslukRepository.kt  → Room'u saran iş mantığı (gün değişimi, JSON dönüşümleri)
data/db/                  → Room: ProfileEntity, AppExcuseEntity, DailyLogEntity + DAO'lar
ai/GeminiClient.kt         → Gemini REST çağrısı (Firebase'siz)
ai/GeminiRepository.kt     → prompt'lar + yerel yedekler
usage/UsageTracker.kt      → kullanım erişimi izni + foreground olay okuma
usage/ScreenTimeReader.kt  → gerçek ekran süresi + en çok kullanılan uygulamalar
usage/TriggerService.kt    → foreground servis: mikro-quest bildirimi + overlay müdahalesi
usage/OverlayController.kt → başka uygulamanın üzerine çıkan popup penceresi
usage/QuestNotifier.kt     → bildirim kanalları
ui/OnboardingScreen.kt     → 6 adımlı kurulum sihirbazı
ui/HomeScreen.kt           → ana ekran
MainViewModel.kt           → tüm durum + akış yönetimi
MainActivity.kt            → izinler, servis başlatma, ekran yönlendirme
```

## Bilinen sınırlar (v1 — bilerek basit tutuldu)
- **Ekran süresi senkronu** sadece uygulama açıkken/servis her `POLL_MS`'de bir çalışır — tam gece yarısı kapanışı yok. Kesin gün sonu için `WorkManager` ile tam gece yarısı tetikleme eklenebilir.
- **Overlay cooldown** bellekte tutulur, servis yeniden başlarsa sıfırlanır — kalıcı hale getirmek için `ProfileEntity.overlayDismissedUntilEpochMin` alanı zaten hazır, sadece bağlanması gerekiyor.
- **Gradle wrapper `.jar`** ikili dosya olduğu için pakete konmadı — Android Studio ilk sync'te üretir; GitHub Actions'ta sistem Gradle'ı kullanılıyor.
- Fontlar sistem serif/mono — Fraunces + IBM Plex Mono `.ttf` eklemek için `res/font`'a koyup `ui/theme/Theme.kt`'i güncelle.

## Sonraki adım fikirleri
- Gün sonu özetini `WorkManager` ile tam gece yarısı otomatik üret (uygulama kapalıyken bile).
- Overlay'de "Yine de devam et" seçilirse quest önerisini de overlay içine göm (tek tıkla tamamlama).
- `AppExcuseEntity` listesini ayarlar ekranından düzenlenebilir yap (kurulumdan sonra mazeret eklemek/çıkarmak için).
