package com.daltech.bosluk.usage

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process

/**
 * "Kullanım Erişimi" (Usage Access) izniyle, izlenen uygulamaların
 * ön plana gelme (açılma) olaylarını sayar. Trigger tespitinin çekirdeği.
 */
object UsageTracker {

    /** Kullanıcı Ayarlar > Kullanım erişimi'nden bu izni verdi mi? */
    fun hasUsageAccess(ctx: Context): Boolean {
        val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * [sinceMs] içindeki zaman aralığında, [packages] listesindeki her paketin
     * kaç kez ön plana geldiğini döndürür. (pkg -> açılış sayısı)
     */
    fun foregroundOpenCounts(
        ctx: Context,
        packages: List<String>,
        sinceMs: Long
    ): Map<String, Int> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - sinceMs, now)
        val counts = HashMap<String, Int>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName in packages) {
                counts[e.packageName] = (counts[e.packageName] ?: 0) + 1
            }
        }
        return counts
    }
}
