package com.daltech.bosluk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daltech.bosluk.UiState
import com.daltech.bosluk.data.Content
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.daltech.bosluk.ui.theme.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    state: UiState,
    onToggleHobby: (String) -> Unit,
    onToggleTrigger: (String) -> Unit,
    onFinish: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) }
    val scroll = rememberScrollState()

    Column(
        Modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scroll)
            .padding(horizontal = 22.dp, vertical = 26.dp)
    ) {
        StepBar(step)
        Spacer(Modifier.height(18.dp))

        if (step == 1) {
            Eyebrow("Kurulum · 1/2")
            Spacer(Modifier.height(14.dp))
            Text("Neyi\nseversin?", style = androidx.compose.material3.MaterialTheme.typography.displaySmall, color = Ink)
            Spacer(Modifier.height(12.dp))
            Text(
                "Quest'lerin buradan doğacak. Boşa kalan dikkatini bu yönlere çekeceğiz — kısıtlamayla değil, davetle.",
                color = Fade, fontSize = 15.sp
            )
            Spacer(Modifier.height(22.dp))
            ChipCloud {
                Content.hobbies.forEach { h ->
                    SelectChip(h.label, h.icon, h.id in state.selectedHobbies) { onToggleHobby(h.id) }
                }
            }
            Spacer(Modifier.height(28.dp))
            PrimaryButton(
                text = "Devam · ${state.selectedHobbies.size} seçili",
                enabled = state.selectedHobbies.isNotEmpty()
            ) { step = 2 }
        } else {
            Eyebrow("Kurulum · 2/2")
            Spacer(Modifier.height(14.dp))
            Text("Nerede\nkaybediyorsun?", style = androidx.compose.material3.MaterialTheme.typography.displaySmall, color = Ink)
            Spacer(Modifier.height(12.dp))
            Text(
                "Dikkatinin en çok sızdığı anlar. Tam o anlarda, doğru quest'i önümüze koyacağız.",
                color = Fade, fontSize = 15.sp
            )
            Spacer(Modifier.height(22.dp))
            ChipCloud {
                Content.triggers.forEach { t ->
                    SelectChip(t.label, t.icon, t.id in state.selectedTriggers, warm = true) { onToggleTrigger(t.id) }
                }
            }
            Spacer(Modifier.height(28.dp))
            PrimaryButton(text = "Defteri aç", enabled = state.selectedTriggers.isNotEmpty(), onClick = onFinish)
            TextButton(onClick = { step = 1 }, modifier = Modifier.fillMaxWidth()) {
                Text("← Geri", color = Fade)
            }
        }
    }
}

@Composable
private fun StepBar(step: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        repeat(3) { i ->
            Box(
                Modifier
                    .weight(1f)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (i < step) Moss else LineColor)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChipCloud(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(9.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) { content() }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Paper)
    ) { Text(text, fontSize = 16.sp) }
}
