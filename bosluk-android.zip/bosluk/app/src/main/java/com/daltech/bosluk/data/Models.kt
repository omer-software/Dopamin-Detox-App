package com.daltech.bosluk.data

data class Hobby(val id: String, val label: String, val icon: String)
data class Trigger(val id: String, val label: String, val icon: String, val packages: List<String> = emptyList())

data class QuestTemplate(
    val id: Int,
    val title: String,
    val desc: String,
    val tags: List<String>,   // hobi/trigger id'leriyle eşleşir
    val xp: Int,
    val dur: String,
    val diff: String
)

enum class QuestStatus { OPEN, COMPLETED, SKIPPED }

data class FeedItem(val quest: QuestTemplate, val status: QuestStatus = QuestStatus.OPEN)
