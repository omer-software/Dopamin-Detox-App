package com.daltech.bosluk.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "bosluk_profile")

data class Profile(
    val onboarded: Boolean = false,
    val hobbies: Set<String> = emptySet(),
    val triggers: Set<String> = emptySet(),
    val weights: MutableMap<String, Double> = mutableMapOf(),
    val xp: Int = 0,
    val streak: Int = 1
)

class ProfileStore(private val ctx: Context) {

    private object Keys {
        val ONBOARDED = intPreferencesKey("onboarded")
        val HOBBIES = stringSetPreferencesKey("hobbies")
        val TRIGGERS = stringSetPreferencesKey("triggers")
        val WEIGHTS = stringPreferencesKey("weights_json")
        val XP = intPreferencesKey("xp")
        val STREAK = intPreferencesKey("streak")
    }

    suspend fun load(): Profile {
        val p = ctx.dataStore.data.first()
        val weights = mutableMapOf<String, Double>()
        p[Keys.WEIGHTS]?.let { json ->
            val o = JSONObject(json)
            o.keys().forEach { k -> weights[k] = o.getDouble(k) }
        }
        return Profile(
            onboarded = (p[Keys.ONBOARDED] ?: 0) == 1,
            hobbies = p[Keys.HOBBIES] ?: emptySet(),
            triggers = p[Keys.TRIGGERS] ?: emptySet(),
            weights = weights,
            xp = p[Keys.XP] ?: 0,
            streak = p[Keys.STREAK] ?: 1
        )
    }

    suspend fun save(profile: Profile) {
        val json = JSONObject()
        profile.weights.forEach { (k, v) -> json.put(k, v) }
        ctx.dataStore.edit { e ->
            e[Keys.ONBOARDED] = if (profile.onboarded) 1 else 0
            e[Keys.HOBBIES] = profile.hobbies
            e[Keys.TRIGGERS] = profile.triggers
            e[Keys.WEIGHTS] = json.toString()
            e[Keys.XP] = profile.xp
            e[Keys.STREAK] = profile.streak
        }
    }

    suspend fun clear() = ctx.dataStore.edit { it.clear() }
}
