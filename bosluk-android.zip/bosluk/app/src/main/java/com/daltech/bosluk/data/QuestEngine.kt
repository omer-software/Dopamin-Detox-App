package com.daltech.bosluk.data

import kotlin.random.Random

/**
 * Kural tabanlı quest motoru + öğrenme döngüsü.
 * weights: tag -> ağırlık. Tamamlanınca artar, atlanınca azalır.
 */
class QuestEngine(
    val hobbies: Set<String>,
    val triggers: Set<String>,
    val weights: MutableMap<String, Double>
) {
    private val active: List<String> get() = (hobbies + triggers).toList()

    fun ensureWeights() {
        active.forEach { weights.putIfAbsent(it, 1.0) }
    }

    private fun score(q: QuestTemplate): Double {
        val hits = q.tags.filter { it in active }
        if (hits.isEmpty()) return -1.0
        val w = hits.map { weights[it] ?: 1.0 }.average()
        return w + Random.nextDouble() * 0.5   // biraz çeşitlilik
    }

    fun buildFeed(n: Int = 5): List<FeedItem> {
        ensureWeights()
        return Content.quests
            .map { it to score(it) }
            .filter { it.second >= 0 }
            .sortedByDescending { it.second }
            .take(n)
            .map { FeedItem(it.first) }
    }

    fun dominantTag(q: QuestTemplate): String? =
        q.tags.filter { it in active }.maxByOrNull { weights[it] ?: 1.0 }

    fun reward(q: QuestTemplate) {
        dominantTag(q)?.let { weights[it] = (weights[it] ?: 1.0) + 0.25 }
    }

    fun demote(q: QuestTemplate) {
        dominantTag(q)?.let { weights[it] = maxOf(0.2, (weights[it] ?: 1.0) - 0.35) }
    }

    fun reason(q: QuestTemplate): String {
        val t = q.tags.firstOrNull { it in active } ?: return "· sana göre"
        Content.hobby(t)?.let { return "· ${it.label} sevdiğin için" }
        Content.trigger(t)?.let { return "· ${it.label} anına karşı" }
        return "· sana göre"
    }
}
