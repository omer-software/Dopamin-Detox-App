package com.daltech.bosluk

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daltech.bosluk.data.Content
import com.daltech.bosluk.data.FeedItem
import com.daltech.bosluk.data.Profile
import com.daltech.bosluk.data.ProfileStore
import com.daltech.bosluk.data.QuestEngine
import com.daltech.bosluk.data.QuestStatus
import com.daltech.bosluk.data.QuestTemplate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiState(
    val loading: Boolean = true,
    val onboarded: Boolean = false,
    val selectedHobbies: Set<String> = emptySet(),
    val selectedTriggers: Set<String> = emptySet(),
    val feed: List<FeedItem> = emptyList(),
    val xp: Int = 0,
    val streak: Int = 1,
    val toast: String? = null,
) {
    val level: Int get() = xp / 150 + 1
    val openCount: Int get() = feed.count { it.status == QuestStatus.OPEN }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ProfileStore(app)
    private var profile = Profile()
    private lateinit var engine: QuestEngine

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            profile = store.load()
            if (profile.onboarded) {
                engine = QuestEngine(profile.hobbies, profile.triggers, profile.weights)
                _ui.value = UiState(
                    loading = false, onboarded = true,
                    selectedHobbies = profile.hobbies, selectedTriggers = profile.triggers,
                    feed = engine.buildFeed(), xp = profile.xp, streak = profile.streak
                )
            } else {
                _ui.value = UiState(loading = false, onboarded = false)
            }
        }
    }

    // ---- onboarding ----
    fun toggleHobby(id: String) = _ui.update {
        it.copy(selectedHobbies = it.selectedHobbies.toggle(id))
    }
    fun toggleTrigger(id: String) = _ui.update {
        it.copy(selectedTriggers = it.selectedTriggers.toggle(id))
    }

    fun finishOnboarding() {
        val s = _ui.value
        profile = profile.copy(
            onboarded = true,
            hobbies = s.selectedHobbies,
            triggers = s.selectedTriggers,
            weights = mutableMapOf()
        )
        engine = QuestEngine(profile.hobbies, profile.triggers, profile.weights)
        engine.ensureWeights()
        _ui.value = s.copy(onboarded = true, feed = engine.buildFeed())
        persist()
    }

    // ---- feed geri bildirim döngüsü ----
    fun complete(item: FeedItem) = updateFeed(item, QuestStatus.COMPLETED) {
        engine.reward(item.quest)
        val ns = _ui.value.copy(xp = _ui.value.xp + item.quest.xp)
        _ui.value = ns.copy(toast = "+${item.quest.xp} odak · bu tür artık daha sık gelecek")
        profile = profile.copy(xp = ns.xp)
    }

    fun skip(item: FeedItem) = updateFeed(item, QuestStatus.SKIPPED) {
        engine.demote(item.quest)
        _ui.value = _ui.value.copy(toast = "Anlaşıldı · bu tür daha az gelecek")
    }

    fun defer(item: FeedItem) {
        _ui.update { st ->
            val list = st.feed.toMutableList()
            list.remove(item); list.add(item)   // sona at
            st.copy(feed = list, toast = "Ertelendi · günün sonuna alındı")
        }
    }

    fun clearToast() = _ui.update { it.copy(toast = null) }

    fun reset() {
        viewModelScope.launch {
            store.clear()
            profile = Profile()
            _ui.value = UiState(loading = false, onboarded = false)
        }
    }

    // ---- helpers ----
    private inline fun updateFeed(item: FeedItem, status: QuestStatus, after: () -> Unit) {
        _ui.update { st ->
            st.copy(feed = st.feed.map { if (it.quest.id == item.quest.id) it.copy(status = status) else it })
        }
        after()
        persist()
    }

    private fun persist() {
        viewModelScope.launch { store.save(profile) }
    }

    private fun Set<String>.toggle(id: String) =
        if (contains(id)) this - id else this + id

    private inline fun MutableStateFlow<UiState>.update(block: (UiState) -> UiState) {
        value = block(value)
    }
}
