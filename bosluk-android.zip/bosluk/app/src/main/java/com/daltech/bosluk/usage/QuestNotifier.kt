package com.daltech.bosluk.usage

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.daltech.bosluk.MainActivity
import com.daltech.bosluk.data.QuestTemplate
import android.app.PendingIntent

object QuestNotifier {

    const val CH_MICRO = "micro_quest"
    const val CH_SERVICE = "trigger_service"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MICRO, "Anlık questler", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Dikkatin dağıldığı anda önerilen mikro-quest"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Arka plan izleme", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Tetikleyici anları izleyen servis"
            }
        )
    }

    /** Foreground service için düşük öncelikli kalıcı bildirim. */
    fun serviceNotification(ctx: Context): Notification =
        NotificationCompat.Builder(ctx, CH_SERVICE)
            .setContentTitle("Boşluk seninle")
            .setContentText("Dikkat sızıntısı anlarını izliyor")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

    /** Tetikleyici yakalandığında fırlatılan mikro-quest bildirimi. */
    fun fireMicroQuest(ctx: Context, appLabel: String, quest: QuestTemplate) {
        val open = PendingIntent.getActivity(
            ctx, quest.id,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CH_MICRO)
            .setContentTitle("$appLabel yerine…")
            .setContentText("${quest.title} · ${quest.dur} · +${quest.xp} odak")
            .setStyle(NotificationCompat.BigTextStyle().bigText("${quest.desc}\n\n${quest.title} · ${quest.dur}"))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(1000 + quest.id, n)
    }
}
