package com.daltech.bosluk.usage

import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.daltech.bosluk.data.Content

/**
 * Basit foreground servis: her [POLL_MS] bir usage olaylarını yoklar.
 * İzlenen bir uygulama son pencerede [THRESHOLD]+ kez açıldıysa,
 * o pakete uygun bir mikro-quest bildirimi fırlatır ve sayaç sıfırlanır.
 *
 * Not: MVP yaklaşımı. Üretimde queryEvents yerine kesintisiz olay akışı /
 * daha akıllı debounce ve "günde en fazla N bildirim" kuralı eklenir.
 */
class TriggerService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val firedRecently = HashSet<String>()

    private val tick = object : Runnable {
        override fun run() {
            check()
            handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        QuestNotifier.ensureChannels(this)
        startForeground(SERVICE_ID, QuestNotifier.serviceNotification(this))
        handler.post(tick)
    }

    private fun check() {
        if (!UsageTracker.hasUsageAccess(this)) return
        val counts = UsageTracker.foregroundOpenCounts(this, Content.watchedPackages, WINDOW_MS)
        counts.forEach { (pkg, n) ->
            if (n >= THRESHOLD && pkg !in firedRecently) {
                val quest = Content.microQuestForPackage(pkg) ?: return@forEach
                QuestNotifier.fireMicroQuest(this, appLabel(pkg), quest)
                firedRecently.add(pkg)                     // aynı pencerede tekrar fırlatma
                handler.postDelayed({ firedRecently.remove(pkg) }, COOLDOWN_MS)
            }
        }
    }

    private fun appLabel(pkg: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        "Bu uygulama"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    companion object {
        private const val SERVICE_ID = 42
        private const val POLL_MS = 60_000L      // 1 dk'da bir yokla
        private const val WINDOW_MS = 15 * 60_000L // son 15 dk'ya bak
        private const val COOLDOWN_MS = 30 * 60_000L // aynı app için 30 dk sus
        private const val THRESHOLD = 3          // 3+ açılış = dikkat sızıntısı
    }
}
