package com.daltech.bosluk.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daltech.bosluk.UiState
import com.daltech.bosluk.data.FeedItem
import com.daltech.bosluk.data.QuestStatus
import com.daltech.bosluk.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FeedScreen(
    state: UiState,
    usageAccessGranted: Boolean,
    onGrantUsageAccess: () -> Unit,
    onComplete: (FeedItem) -> Unit,
    onSkip: (FeedItem) -> Unit,
    onDefer: (FeedItem) -> Unit,
    onReset: () -> Unit,
    onToastShown: () -> Unit,
) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.toast) {
        state.toast?.let { snackbar.showSnackbar(it); onToastShown() }
    }

    Scaffold(
        containerColor = Paper,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 22.dp),
            contentPadding = PaddingValues(top = 26.dp, bottom = 30.dp)
        ) {
            item { Header(state) }
            item { StatsRow(state) }
            if (!usageAccessGranted) item { UsageBanner(onGrantUsageAccess) }
            item {
                Text(
                    if (state.openCount > 0) "${state.openCount} QUEST BEKLİYOR" else "GÜN TAMAM",
                    color = Moss, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                    letterSpacing = 2.sp, modifier = Modifier.padding(top = 22.dp, bottom = 12.dp)
                )
            }
            if (state.openCount == 0) {
                item { EmptyState() }
            }
            items(state.feed, key = { it.quest.id }) { item ->
                QuestCard(item, state, onComplete, onSkip, onDefer)
                Spacer(Modifier.height(14.dp))
            }
            item {
                TextButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) {
                    Text("Kurulumu sıfırla", color = Fade)
                }
            }
        }
    }
}

@Composable
private fun Header(state: UiState) {
    val today = remember { SimpleDateFormat("EEEE, d MMMM", Locale("tr")).format(Date()) }
    Column {
        Text("Bugünün defteri", style = MaterialTheme.typography.headlineMedium, color = Ink)
        Text(
            today.uppercase(Locale("tr")),
            color = Fade, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
            letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun StatsRow(state: UiState) {
    Column(Modifier.padding(top = 20.dp)) {
        HorizontalDivider(color = LineColor)
        Row(
            Modifier.fillMaxWidth().padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Stat(state.streak.toString(), "gün seri")
            Stat(state.xp.toString(), "odak puanı")
            Stat(state.level.toString(), "seviye")
        }
        HorizontalDivider(color = LineColor)
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column {
        Text(value, fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, color = MossDeep)
        Text(label.uppercase(), color = Fade, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun UsageBanner(onGrant: () -> Unit) {
    Column(
        Modifier
            .padding(top = 18.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFEFE3CE))
            .border(BorderStroke(1.dp, Brass.copy(alpha = 0.4f)), RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Text("Anlık questleri aç", fontFamily = FontFamily.Serif, fontSize = 17.sp, color = Ink)
        Text(
            "Dikkatin dağıldığı anda quest fırlatmamız için “Kullanım erişimi” izni gerekiyor.",
            color = Fade, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )
        Button(
            onClick = onGrant,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Brass, contentColor = Color.White)
        ) { Text("İzin ver") }
    }
}

@Composable
private fun QuestCard(
    item: FeedItem,
    state: UiState,
    onComplete: (FeedItem) -> Unit,
    onSkip: (FeedItem) -> Unit,
    onDefer: (FeedItem) -> Unit,
) {
    val q = item.quest
    val completed = item.status == QuestStatus.COMPLETED
    val skipped = item.status == QuestStatus.SKIPPED
    if (skipped) return

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(PaperCard)
            .border(BorderStroke(1.dp, LineColor), RoundedCornerShape(16.dp))
            .padding(18.dp)
            .then(if (completed) Modifier.alpha(0.55f) else Modifier)
    ) {
        Column {
            Text(
                reasonLine(q, state),
                color = Moss, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, letterSpacing = 0.5.sp
            )
            Spacer(Modifier.height(9.dp))
            Text(q.title, style = MaterialTheme.typography.titleLarge, color = Ink)
            Spacer(Modifier.height(8.dp))
            Text(q.desc, color = Fade, fontSize = 13.5.sp, lineHeight = 19.sp)
            Spacer(Modifier.height(13.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetaTag(q.dur); MetaTag(q.diff); MetaTag("+${q.xp} odak", reward = true)
            }
            if (completed) {
                Spacer(Modifier.height(12.dp))
                Text("TAMAM ✓", color = Moss, fontFamily = FontFamily.Monospace, fontSize = 13.sp, letterSpacing = 2.sp)
            } else {
                Spacer(Modifier.height(15.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    CardAction("Tamamla", Modifier.weight(1.6f), filled = true) { onComplete(item) }
                    CardAction("Atla", Modifier.weight(0.9f)) { onSkip(item) }
                    CardAction("Ertele", Modifier.weight(0.9f)) { onDefer(item) }
                }
            }
        }
    }
}

@Composable
private fun MetaTag(text: String, reward: Boolean = false) {
    Text(
        text,
        color = if (reward) Color(0xFF7A5B15) else MossDeep,
        fontFamily = FontFamily.Monospace, fontSize = 10.5.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (reward) Brass.copy(alpha = 0.16f) else Paper2)
            .padding(horizontal = 9.dp, vertical = 4.dp)
    )
}

@Composable
private fun CardAction(text: String, modifier: Modifier, filled: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (filled) Moss else Color.Transparent)
            .border(BorderStroke(1.dp, if (filled) Moss else LineColor), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (filled) Paper else Ink, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Defter bugünlük dolu.", fontFamily = FontFamily.Serif, fontSize = 22.sp, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(
            "Yarın profiline göre yenileri gelecek. Şimdi telefonu bırakma sırası sende.",
            color = Fade, fontSize = 14.sp, textAlign = TextAlign.Center
        )
    }
}

private fun reasonLine(q: com.daltech.bosluk.data.QuestTemplate, state: UiState): String {
    val active = state.selectedHobbies + state.selectedTriggers
    val t = q.tags.firstOrNull { it in active } ?: return "· sana göre"
    com.daltech.bosluk.data.Content.hobby(t)?.let { return "· ${it.label} sevdiğin için".uppercase(Locale("tr")) }
    com.daltech.bosluk.data.Content.trigger(t)?.let { return "· ${it.label} anına karşı".uppercase(Locale("tr")) }
    return "· SANA GÖRE"
}
