package com.daltech.bosluk

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daltech.bosluk.ui.FeedScreen
import com.daltech.bosluk.ui.OnboardingScreen
import com.daltech.bosluk.ui.theme.BoslukTheme
import com.daltech.bosluk.usage.QuestNotifier
import com.daltech.bosluk.usage.TriggerService
import com.daltech.bosluk.usage.UsageTracker

class MainActivity : ComponentActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* sonuç önemli değil */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        QuestNotifier.ensureChannels(this)
        askNotificationPermission()

        setContent {
            BoslukTheme {
                val vm: MainViewModel = viewModel()
                val state by vm.ui.collectAsStateWithLifecycle()

                // Usage-access durumu ekrana her dönüşte tazelensin
                var usageGranted by remember { mutableStateOf(UsageTracker.hasUsageAccess(this)) }
                LaunchedEffect(Unit) { usageGranted = UsageTracker.hasUsageAccess(this@MainActivity) }

                when {
                    state.loading -> LoadingBox()
                    !state.onboarded -> OnboardingScreen(
                        state = state,
                        onToggleHobby = vm::toggleHobby,
                        onToggleTrigger = vm::toggleTrigger,
                        onFinish = vm::finishOnboarding
                    )
                    else -> FeedScreen(
                        state = state,
                        usageAccessGranted = usageGranted,
                        onGrantUsageAccess = { openUsageAccessSettings() },
                        onComplete = vm::complete,
                        onSkip = vm::skip,
                        onDefer = vm::defer,
                        onReset = vm::reset,
                        onToastShown = vm::clearToast
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // İzin verildiyse izleme servisini başlat
        if (UsageTracker.hasUsageAccess(this)) startTriggerService()
    }

    private fun startTriggerService() {
        val intent = Intent(this, TriggerService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun openUsageAccessSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@androidx.compose.runtime.Composable
private fun LoadingBox() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}
