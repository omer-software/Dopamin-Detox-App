# Boşluk — side-questli dopamin detoksu (Android)

Native **Kotlin + Jetpack Compose**. HTML prototipteki tüm döngü + HTML'in yapamadığı asıl parça:
**başka bir uygulama fazla açıldığında o an mikro-quest bildirimi** (`UsageStatsManager`).

## Kurma / çalıştırma
1. Klasörü **Android Studio** (Hedgehog+ / AGP 8.5) ile aç.
2. İlk açılışta Gradle sync otomatik başlar; SDK ve bağımlılıkları indirir.
   - Komut satırından derleyeceksen önce `gradle wrapper` çalıştır (wrapper .jar repoya konmadı), sonra `./gradlew assembleDebug`.
3. `minSdk 26`, `targetSdk 34`. Emülatör veya gerçek cihazda çalışır.

## Akış
- **Onboarding** → hobiler + hassas noktalar seçilir (`ProfileStore` / DataStore ile kalıcı).
- **Feed** → `QuestEngine` profile göre havuzdan puanlayıp 5 quest dizer.
- **Öğrenme döngüsü** → Tamamla ağırlığı artırır, Atla azaltır, Ertele sona atar. Ağırlıklar diske yazılır.

## Trigger bildirimini test etme (asıl fark)
1. Feed ekranındaki **"Anlık questleri aç"** kartından **İzin ver** → Ayarlar > Kullanım erişimi'nde Boşluk'u aç.
2. Geri dön; uygulama `onResume`'da `TriggerService`'i (foreground) başlatır.
3. İzlenen bir uygulamayı (varsayılan: Instagram / YouTube / TikTok / X / Facebook — `Content.triggers[].packages`) **son 15 dk içinde 3+ kez** aç.
4. Servis (dakikada bir yoklar) eşiği görünce o pakete uygun **mikro-quest bildirimi** fırlatır; aynı app için 30 dk susar.

> Hızlı test için `TriggerService`'te `POLL_MS`, `WINDOW_MS`, `THRESHOLD`, `COOLDOWN_MS` değerlerini küçült.

## Dosya haritası
```
data/Content.kt      → hobiler, tetikleyiciler (paket adlarıyla), quest havuzu
data/QuestEngine.kt  → puanlama + ağırlık öğrenme
data/ProfileStore.kt → DataStore kalıcılık
usage/UsageTracker.kt→ Kullanım erişimi + ön plan açılış sayımı
usage/TriggerService.kt→ foreground servis, eşik → bildirim
usage/QuestNotifier.kt→ kanallar + mikro-quest bildirimi
ui/…                 → Onboarding + Feed (Compose)
MainViewModel.kt     → durum + döngü
```

## Sonraki adımlar (mimari)
- **Supabase**: `quest_templates`, `user_quests`, `user_tag_weights` tabloları; feed üretimini Edge Function'a taşı.
- **LLM quest üretimi**: statik metinler yerine Gemini ile kişiselleştirme (DeneAI'deki pattern).
- **Servis dayanıklılığı**: `WorkManager` + boot receiver ile yeniden başlatma, "günde en fazla N bildirim" kuralı, akıllı debounce.
- **Fontlar**: Fraunces / IBM Plex Mono `.ttf`'lerini `res/font`'a koyup `Theme.kt`'te bağla (analog defter hissi tamamlanır).

## Bilinen sınır
- Gradle wrapper `.jar` ikili olduğu için pakete konmadı — Android Studio ilk sync'te üretir.
- Launcher ikonu basit adaptive-icon (vektör pusula). İstersen değiştir.
